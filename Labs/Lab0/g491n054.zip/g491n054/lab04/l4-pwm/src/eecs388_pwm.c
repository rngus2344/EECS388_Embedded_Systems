#include <stdio.h>
#include <stdint.h>

#include "eecs388_lib.h"

#define SERVO_PULSE_MAX 2400    /* 2400 us */
#define SERVO_PULSE_MIN 544     /* 544 us */
#define SERVO_PERIOD    20000   /* 20000 us (20ms) */

/**
 * Generate a pwm signal
 * 
 * Input:
 *  @gpio   gpio number
 *  @pos    degree [0,180]
 */
void servo(int gpio, int pos)
{
    // To move the motor arm, the duty cycle needs to be in the range
    // 544 us to 2400 us

    // this code example I gave has a 50% duty cycle (10000 us)
    // You will need to modify the two delay amounts

    // Bad example! But right now what this is doing is 
    // writing the angle 0 degrees

    // So now, I'll write 90 degrees
    double slope = 1.0 * (2400 - 544) / (180 - 90);
    double output = 544 + slope * (pos - 90);

    gpio_write(gpio, ON);
    delay_usec(output);
    gpio_write(gpio, OFF);
    delay_usec(SERVO_PERIOD - output);
}

int main()
{
    int gpio = PIN_19;
    gpio_mode(gpio, OUTPUT);

    while (1) {
        for (int pos = 0; pos <= 180; pos += 30) {
            printf("pos: %d (degree)\n", pos);
            /* control the servor for 1 sec duration */
            for (int i = 0; i < 50; i++)
                servo(gpio, pos);
        }
    }
}