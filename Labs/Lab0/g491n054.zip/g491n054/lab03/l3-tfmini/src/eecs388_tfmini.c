/**
 * This program read the distance data from TFmini lidar sensor and 
 * print the read data and controls LED depending on the measured distance.
 */
#include <stdint.h>
#include <stdio.h>

#include "eecs388_lib.h"

int main()
{
    gpio_mode(RED_LED, OUTPUT);
    gpio_mode(GREEN_LED, OUTPUT);
    ser_setup();

    ser_printline("Setup completed.\n");

    int led_gpio = GREEN_LED;
    int dist; // read distance value. 

    while (1) {
        /* 
            Task 1: 
            - read a data frame from the TFmini sensor
            - print the read distance data. e.g., "dist: 45 cm"
              (you can use either printf or sprintf & ser_printline function)
        */
        if ('Y' == ser_read(0) && 'Y' == ser_read(0)) {
            // YOUR CODE HERE
            int distL;
            int distH;

            distL = ser_read(0); // distL == low bit
            distH = ser_read(0); // distH == high bit

            dist = distL | (distH << 8);

            printf("dist: %d cm\n", dist);
        }

        /* 
            Task 2: 
            - turn on the red light if the distance is less than 50cm. 
            - otherwise turn on the green light 
        */
        if (dist < 50) {
            led_gpio = RED_LED;
            gpio_write(led_gpio, ON);
            gpio_write(GREEN_LED, OFF);
        } else {
            led_gpio = GREEN_LED;
            gpio_write(led_gpio, ON);
            gpio_write(RED_LED, OFF);
        }
    }
}